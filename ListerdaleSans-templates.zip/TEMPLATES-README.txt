Listerdale Sans templates

ListerdaleSans-Template.potx  PowerPoint template (fonts embedded)
ListerdaleSans-Template.dotx  Word template
ListerdaleSans-Template.otp   LibreOffice Impress template
ListerdaleSans-Template.ott   LibreOffice Writer template

Headings default to Listerdale Sans Display, body text to Listerdale Sans,
with 1.5 line spacing and left-aligned text built into the styles.

Install the fonts first (from the font download) - the Word and LibreOffice
templates need them on your system. Free to use and share, like the fonts.
