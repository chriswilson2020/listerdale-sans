Listerdale Sans

One family, four weights (Light, Regular, SemiBold, Bold), two optical cuts:

  Listerdale Sans          the text cut - body copy and everything you read.
                           Carries gentle stroke grading toward the baseline.
  Listerdale Sans Display  the large-size cut - headings, titles, posters and
                           anything above about 20pt. Same letterforms and
                           widths, crisp even strokes.

Accessible by design in both cuts: distinct l / I / 1 forms, tailed q,
uncrossed w, lining figures, widened letter and word spacing.

Free to use, embed and share, commercially or otherwise.

Sharing the fonts onward? Keep OFL.txt and the embedded copyright notice
with the files (they carry the attribution to Listerdale Life Sciences BV),
and the font files may not be sold. Redistribution that strips the notices
is not permitted.

A credit or link back when you use it publicly is appreciated - never required.

Full licence terms: OFL.txt.
