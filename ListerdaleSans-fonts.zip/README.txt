Listerdale Sans

One family, four weights: Light, Regular, SemiBold, Bold.
Accessible by design: distinct l / I / 1 forms, tailed q, uncrossed w,
lining figures, widened letter and word spacing, and stroke weight that
grades gently heavier toward the baseline.

Free to use, embed and share, commercially or otherwise.

Sharing the fonts onward? Two conditions travel with them under the
licence: keep OFL.txt and the embedded copyright notice with the files
(they carry the attribution to Listerdale Life Sciences BV), and the
font files may not be sold. Redistribution that strips the notices
is not permitted.

If you use the typeface somewhere public, a credit or a link back is
appreciated - never required.

Full licence terms: OFL.txt.
